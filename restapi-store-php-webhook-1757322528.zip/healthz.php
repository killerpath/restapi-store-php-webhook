<?php
require_once __DIR__ . '/lib.php';
json_response(['status' => 'ok', 'project' => PROJECT_KEY]);
?>
