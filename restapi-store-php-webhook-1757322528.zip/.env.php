<?php
// .env.php — configuration for restapi.store Jira webhook (PHP)
define('JIRA_SITE', 'https://digitas.atlassian.net');
define('JIRA_EMAIL', 'piyush.singh1@digitas.com');
define('JIRA_API_TOKEN', 'REPLACE_ME'); // <-- put your Atlassian API token here
define('PROJECT_KEY', 'PG');
define('TOTAL_SUB_TICKETS_FIELD_NAME', 'Total Sub Tickets');
define('TOTAL_SUB_TICKETS_FIELD_ID', ''); // optional: e.g. 'customfield_17054'
define('WEBHOOK_SECRET', 'change-me'); // <-- set a strong secret; must match Jira Automation header

// child types to count as direct children (case-insensitive)
define('ALLOWED_CHILD_TYPES', 'Story,Task');
define('COUNT_SUBTASKS', true);
?>
